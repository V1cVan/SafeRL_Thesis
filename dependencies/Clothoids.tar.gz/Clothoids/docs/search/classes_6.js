var searchData=
[
  ['solve2x2',['Solve2x2',['../df/d84/class_g2lib_1_1_solve2x2.html',1,'G2lib']]]
];
