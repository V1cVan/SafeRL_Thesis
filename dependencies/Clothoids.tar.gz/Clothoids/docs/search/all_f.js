var searchData=
[
  ['sinc',['Sinc',['../d4/d9f/namespace_g2lib.html#a081bc3efca6442933577b14d6f3c2a06',1,'G2lib']]],
  ['sinc_5fd',['Sinc_D',['../d4/d9f/namespace_g2lib.html#a70d38da7135fe9aa83b9e0d0e6ee7979',1,'G2lib']]],
  ['sinc_5fdd',['Sinc_DD',['../d4/d9f/namespace_g2lib.html#a069d980b307edd06a1e9401e1a7bd5b4',1,'G2lib']]],
  ['sinc_5fddd',['Sinc_DDD',['../d4/d9f/namespace_g2lib.html#a698f23b0a8d2f0dd431c908ba7bce967',1,'G2lib']]],
  ['solve2x2',['Solve2x2',['../df/d84/class_g2lib_1_1_solve2x2.html',1,'G2lib']]],
  ['solvelinearquadratic',['solveLinearQuadratic',['../d4/d9f/namespace_g2lib.html#aeebee0c0de28155447b2c5f0547b0b92',1,'G2lib']]],
  ['solvelinearquadratic2',['solveLinearQuadratic2',['../d4/d9f/namespace_g2lib.html#afa9a9719ade11579b722aae68f7d4379',1,'G2lib']]],
  ['sqrtmachepsi',['sqrtMachepsi',['../d4/d9f/namespace_g2lib.html#ae2356d66f8dc864eddfdd3ad1db95266',1,'G2lib']]]
];
