var searchData=
[
  ['polynomialroots',['PolynomialRoots',['../d5/d44/namespace_polynomial_roots.html',1,'']]]
];
