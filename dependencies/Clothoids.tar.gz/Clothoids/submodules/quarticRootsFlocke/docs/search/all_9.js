var searchData=
[
  ['setup',['setup',['../d5/ded/class_polynomial_roots_1_1_quadratic.html#a23f99bb9dc9085736467a7d448c909b2',1,'PolynomialRoots::Quadratic::setup()'],['../d9/df7/class_polynomial_roots_1_1_cubic.html#ad08ac921b9175e4f6cff3a89bb232c3b',1,'PolynomialRoots::Cubic::setup()'],['../d8/dec/class_polynomial_roots_1_1_quartic.html#a456cd442a681a5dd66956a1d553b1a41',1,'PolynomialRoots::Quartic::setup()']]]
];
