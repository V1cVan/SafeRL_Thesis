var searchData=
[
  ['cubic',['Cubic',['../d9/df7/class_polynomial_roots_1_1_cubic.html',1,'PolynomialRoots']]]
];
