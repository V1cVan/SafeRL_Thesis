var searchData=
[
  ['doubleroot',['doubleRoot',['../d5/ded/class_polynomial_roots_1_1_quadratic.html#adef2391e342dbda3a8aa7daee125a859',1,'PolynomialRoots::Quadratic::doubleRoot()'],['../d9/df7/class_polynomial_roots_1_1_cubic.html#a6aa77e261ab9ba83c2e5f05ce9f5e065',1,'PolynomialRoots::Cubic::doubleRoot()']]]
];
