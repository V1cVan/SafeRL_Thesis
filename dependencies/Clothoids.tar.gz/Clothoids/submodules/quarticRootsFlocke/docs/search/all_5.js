var searchData=
[
  ['numcomplexroots',['numComplexRoots',['../d8/dec/class_polynomial_roots_1_1_quartic.html#a0932673f6b5a4fae631a5d27b2fe860a',1,'PolynomialRoots::Quartic']]],
  ['numrealroots',['numRealRoots',['../d8/dec/class_polynomial_roots_1_1_quartic.html#af647c59add0df604161cf6e3bc64e1c0',1,'PolynomialRoots::Quartic']]],
  ['numroots',['numRoots',['../d5/ded/class_polynomial_roots_1_1_quadratic.html#a0acee845244aae9f51add7dd478cc30d',1,'PolynomialRoots::Quadratic::numRoots()'],['../d9/df7/class_polynomial_roots_1_1_cubic.html#a86871c6ceafe895744a5bd0dade70779',1,'PolynomialRoots::Cubic::numRoots()'],['../d8/dec/class_polynomial_roots_1_1_quartic.html#a40ab733d024bb691c5a969db3369c43c',1,'PolynomialRoots::Quartic::numRoots()']]]
];
